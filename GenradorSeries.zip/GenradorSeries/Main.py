#GENERADOR DE ONDAS A PARTIR DE SERIES DE FOURIER
#DESARROLLADO POR:
#David Santiago Granados
#Ismael Jesus Lopez

#Importamos librerias
from sympy import *
from sympy.abc import t, n
import numpy as np
import matplotlib.pyplot as plt
from scipy import integrate as ipo


#Definimos metodo Principal
def Main():
    #Inicializamos la variable del menu
    sel=0
    #Creamos while para regresar al menu principal
    while sel!=4:
        #Menu
        print ("BIENVENIDO AL GENERADOR DE ONDAS A PARTIR DE LA SERIE DE FOURIER")
        print ("Seleccione el tipo de onda que desea generar")
        print (" 1.Onda Cuadrada")
        print (" 2.Onda Triangular")
        print (" 3.Onda Diente de Sierra")
        print (" 4.Salir")
        sel = input ("")

        #Opcion onda cuadrada
        if sel==1:
            generar()
        #Opcion onda triangular
        elif sel==2:
            triangular()
        #Opcion onda diente de sierra
        elif sel==3:
            sierra()

#Metodo Onda cuadrada
def generar():

    #Para desarrollar la Serie debemos encontrar 3 valores: ao-an-bn
    #integramos la funcion (2/pi)
    #Se integra entre 0 y pi/2
    ao = integrate(2 / pi, (t, 0, pi / 2))
    print "\n"+"a0 = "
    pprint(ao)
    #integramos (2/pi)*cos(2nt)
    an = integrate((2 / pi) * cos(2 * n * t), (t, 0, pi / 2))
    print "\n"+"an = "
    pprint(an)
    bn = together(integrate((2 / pi) * sin(2 * n * t), (t, 0, pi / 2)))
    #integramos (2/pi*cos(2nt)
    print "\n"+"bn = "
    pprint(bn)


    print "\n"+"f(x) = "
    armonicos = 100
    serie = (ao/2)
    for i in range(1, armonicos + 1):
        serie = serie + (an*cos(2*n*t)).subs(n, i)
    for j in range(1, armonicos + 1):
        serie = serie + (bn*sin(2*n*t)).subs(n, j)

    pprint(serie)
    plotting.plot(serie, ylim=(-0.5, 1.5), xlim=(-0.5,5))

#Metodo onda triangular
def triangular():
    print ("Triangular")
    from pylab import *
    from numpy import pi, arange
    x = arange (-3, 3, 0.01)
    y = 4./pi**2 * 1 * sin(pi*x)
    for n in range (3,29,2):
        y = y + 4./pi**2 * ((-1)**n-1/2)/n**2 * sin(n*pi*x)

    plot(x,y)
    show ()

#Metodo Onda diente de sierra
def sierra():
    i=0
    print ("Sierra")
    #Integramos
    a0, err0 = ipo.quad(lambda x: x,-pi,pi)
    #Hallamos a0
    a0 = (1/pi)*a0
    y = a0*0.5
    z = np.arange(0,5*np.pi,0.01)
    fig = plt.figure()
    N = 10 #Numero de muestras
    i = 1 #Se inicializa el contador

    while (i<=N):
        ai, erri = ipo.quad(lambda x: x * cos(i*x),-pi,pi)
        ai = (1/pi)*ai
        bi, erri = ipo.quad(lambda x: x * sin(i*x),-pi,pi)
        bi = (1/pi)*bi
        y += ai*np.cos(i*z) + bi*np.sin(i*z)
        i = i+1 #Se aumenta el contador
    plt.plot(z,y)
    plt.show()

if __name__ == "__main__":
    Main()
